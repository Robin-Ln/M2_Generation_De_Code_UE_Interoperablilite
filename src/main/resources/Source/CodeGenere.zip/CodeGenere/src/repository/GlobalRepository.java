package repository;

import org.w3c.dom.*;
import repository.instance.AbstractInstance;
import repository.repository.AbstractRepository;
import repository.repository.FlotteInstanceRepository;
import repository.repository.SateliteInstanceRepository;
import repository.visiteurs.VisiteurInstanceEcrire;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.util.*;

public class GlobalRepository {

    private Map<String, AbstractRepository> repositoryMap;

    private Set<AbstractInstance> instances;

    private Integer index;

    public GlobalRepository() {
        this.repositoryMap = Map.ofEntries(
                new AbstractMap.SimpleEntry<String, AbstractRepository>("FlotteInstance", new FlotteInstanceRepository()),
                new AbstractMap.SimpleEntry<String, AbstractRepository>("SateliteInstance", new SateliteInstanceRepository())
        );
        this.instances = new HashSet<>();
        this.index = 0;
    }


    public List<AbstractInstance> lire(Document document) {
        List<AbstractInstance> instances = new ArrayList<>();
        Element root = document.getDocumentElement();
        NodeList nodeList = root.getChildNodes();
        for (int i = 0; i < nodeList.getLength(); i++) {
            Node node = nodeList.item(i);
            if (node.getNodeType() == Node.ELEMENT_NODE) {
                Element instanceElement = (Element) node;
                AbstractRepository<?> repository = this.repositoryMap.get(instanceElement.getTagName());
                instances.add(repository.lire(instanceElement, document));
            }
        }
        return instances;
    }

    public Document ecrire() {
        Document document = null;
        try {
            DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
            DOMImplementation domImplementation = documentBuilder.getDOMImplementation();

            document = domImplementation.createDocument("", "Instances", null);

            VisiteurInstanceEcrire visiteur = new VisiteurInstanceEcrire(document);
            for (AbstractInstance instance : this.instances) {
                instance.accept(visiteur);
            }

            return document;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public void addInstance(AbstractInstance instance) {
        this.initId(instance);
        this.instances.add(instance);
    }


    private void initId(AbstractInstance instance) {
        String id = "id" + this.index++;
        instance.setId(id);
    }

}
