package repository.instance;

import repository.visiteurs.VisitableInstance;

import java.util.Objects;

public abstract class AbstractInstance implements VisitableInstance {

    /**
     * Attributes
     */
    private String id;

    /**
     * Methodes
     */
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AbstractInstance instance = (AbstractInstance) o;
        return id.equals(instance.id);
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }

    /**
     * Accesseurs
     */
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
