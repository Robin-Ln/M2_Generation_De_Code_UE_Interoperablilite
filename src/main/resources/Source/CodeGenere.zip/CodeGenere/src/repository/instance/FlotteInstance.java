package repository.instance;

import repository.visiteurs.VisiteurInstance;

import java.util.ArrayList;
import java.util.List;

public class FlotteInstance extends AbstractInstance {
    /**
     * Attributes
     */
    private List<SateliteInstance> satelites;

    /**
     * Constructeur
     */
    public FlotteInstance() {
        this.satelites = new ArrayList<>();
    }

    /**
     * Méthodes de l'interface Visiteur
     */

    @Override
    public void accept(VisiteurInstance visiteurInstance) {
        visiteurInstance.visite(this);
    }

    /**
     * Accesseur
     */
    public List<SateliteInstance> getSatelites() {
        return satelites;
    }

    public void setSatelites(List<SateliteInstance> satelites) {
        this.satelites = satelites;
    }
}
