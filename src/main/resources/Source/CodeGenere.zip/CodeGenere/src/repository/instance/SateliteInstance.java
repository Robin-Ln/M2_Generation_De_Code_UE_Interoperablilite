package repository.instance;

import repository.visiteurs.VisiteurInstance;

public class SateliteInstance extends AbstractInstance {
    /**
     * Attribute
     */
    private String nom;
    private FlotteInstance parent;

    /**
     * Constructeur
     */
    public SateliteInstance() {
    }

    /**
     * Méthodes de l'interface Visiteur
     */

    @Override
    public void accept(VisiteurInstance visiteurInstance) {
        visiteurInstance.visite(this);
    }

    /**
     * Accesseurs
     */
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public FlotteInstance getParent() {
        return parent;
    }

    public void setParent(FlotteInstance parent) {
        this.parent = parent;
    }
}
