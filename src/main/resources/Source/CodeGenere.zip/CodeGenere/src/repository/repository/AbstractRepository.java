package repository.repository;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import repository.instance.AbstractInstance;

import java.util.HashMap;
import java.util.Map;

public abstract class AbstractRepository<Instance extends AbstractInstance> {

    private static Map<String, AbstractInstance> INSTANCES;

    /**
     * Constructeurs
     */
    public AbstractRepository() {
        if (AbstractRepository.INSTANCES == null) {
            AbstractRepository.INSTANCES = new HashMap<>();
        }
    }

    /**
     * Methodes
     */
    public Boolean instanceExist(String id) {
        return AbstractRepository.INSTANCES.containsKey(id);
    }

    public AbstractInstance getInstance(String id) {
        if (this.instanceExist(id)) {
            return AbstractRepository.INSTANCES.get(id);
        }
        throw new RuntimeException("fail getInstance in AbstractRepository");
    }

    public void addInstance(AbstractInstance instance) {
        AbstractRepository.INSTANCES.put(instance.getId(), instance);
    }

    public Element createElement(AbstractInstance instance, Document document) {
        Element element = document.createElement(instance.getClass().getSimpleName());
        element.setAttribute("id", instance.getId());
        return element;
    }

    /**
     * Methodes abstraite
     */

    public abstract AbstractInstance lire(Element element, Document document);

    public abstract Element ecrire(Instance instance, Document document);

}
