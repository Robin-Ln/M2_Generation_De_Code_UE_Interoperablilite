package repository.repository;

import modele.Satelite;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import repository.instance.AbstractInstance;
import repository.instance.FlotteInstance;
import repository.instance.SateliteInstance;

public class FlotteInstanceRepository extends AbstractRepository<FlotteInstance> {

    public FlotteInstanceRepository() {
        super();
    }

    public AbstractInstance lire(Element element, Document document) {

        String idInstance = element.getAttribute("id");
        if (this.instanceExist(idInstance)) {
            return this.getInstance(idInstance);
        }

        FlotteInstance instance = new FlotteInstance();
        instance.setId(idInstance);
        this.addInstance(instance);

        String[] ids = element.getAttribute("satelites").split(" ");

        SateliteInstanceRepository repository = new SateliteInstanceRepository();
        for (String id : ids) {
            AbstractInstance abstractInstance = repository.lire(document.getElementById(id), document);
            SateliteInstance sateliteInstance = (SateliteInstance) abstractInstance;
            instance.getSatelites().add(sateliteInstance);
        }

        return instance;

    }

    public Element ecrire(FlotteInstance instance, Document document) {
        Element element = this.createElement(instance, document);

        String ids = new String();
        for (SateliteInstance sateliteInstance : instance.getSatelites()) {
            ids += sateliteInstance.getId() + " ";
        }
        element.setAttribute("satelites", ids);

        return element;

    }
}
