package repository.repository;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import repository.instance.AbstractInstance;
import repository.instance.FlotteInstance;
import repository.instance.SateliteInstance;

public class SateliteInstanceRepository extends AbstractRepository<SateliteInstance> {

    public SateliteInstanceRepository() {
        super();
    }

    public AbstractInstance lire(Element element, Document document) {

        String id = element.getAttribute("id");
        if (this.instanceExist(id)) {
            return this.getInstance(id);
        }

        SateliteInstance instance = new SateliteInstance();
        instance.setId(id);
        this.addInstance(instance);



        instance.setNom(element.getAttribute("nom"));

        FlotteInstanceRepository repository = new FlotteInstanceRepository();
        Element parentElement = document.getElementById(element.getAttribute("parent"));
        instance.setParent((FlotteInstance) repository.lire(parentElement, document));

        return instance;

    }

    public Element ecrire(SateliteInstance instance, Document document) {
        Element element = this.createElement(instance, document);
        element.setAttribute("nom", instance.getNom());
        element.setAttribute("parent", instance.getParent().getId());
        return element;
    }
}
