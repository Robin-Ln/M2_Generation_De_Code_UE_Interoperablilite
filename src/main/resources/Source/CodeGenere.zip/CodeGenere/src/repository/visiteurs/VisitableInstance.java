package repository.visiteurs;

public interface VisitableInstance {
    void accept(VisiteurInstance visiteurInstance);
}
