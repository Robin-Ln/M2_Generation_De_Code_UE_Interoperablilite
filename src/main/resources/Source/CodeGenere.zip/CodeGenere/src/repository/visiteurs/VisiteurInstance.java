package repository.visiteurs;

import repository.instance.FlotteInstance;
import repository.instance.SateliteInstance;

public interface VisiteurInstance {

    void visite(FlotteInstance flotteInstance);

    void visite(SateliteInstance sateliteInstance);
}
