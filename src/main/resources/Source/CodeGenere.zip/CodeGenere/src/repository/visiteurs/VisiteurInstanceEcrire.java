package repository.visiteurs;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import repository.instance.FlotteInstance;
import repository.instance.SateliteInstance;
import repository.repository.FlotteInstanceRepository;
import repository.repository.SateliteInstanceRepository;


public class VisiteurInstanceEcrire implements VisiteurInstance {

    private Document document;

    public VisiteurInstanceEcrire(Document document) {
        this.document = document;
    }

    @Override
    public void visite(FlotteInstance instance) {
        FlotteInstanceRepository repository = new FlotteInstanceRepository();
        Element element = repository.ecrire(instance, this.document);
        this.document.getDocumentElement().appendChild(element);

    }

    @Override
    public void visite(SateliteInstance instance) {
        SateliteInstanceRepository repository = new SateliteInstanceRepository();
        Element element = repository.ecrire(instance, this.document);
        this.document.getDocumentElement().appendChild(element);
    }

}
