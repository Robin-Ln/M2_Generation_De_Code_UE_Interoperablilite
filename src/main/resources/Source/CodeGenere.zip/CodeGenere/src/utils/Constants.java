package utils;

public class Constants {

    /**
     * Constructeur
     */
    private Constants() {
    }

    public static final String PATH_XML_INSTANCE = "test/resources/instances.xml";
}
