package repository;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import repository.instance.AbstractInstance;
import repository.instance.FlotteInstance;
import repository.instance.SateliteInstance;
import utils.Constants;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.fail;


class GlobalRepositoryTest {

    GlobalRepositoryTest() throws ParserConfigurationException {
    }

    private GlobalRepository globalRepository;
    private List<AbstractInstance> instances;
    private Document document;

    private final DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
    private final DocumentBuilder builder = factory.newDocumentBuilder();


    @BeforeEach
    void setUp() {
        globalRepository = new GlobalRepository();

        FlotteInstance flotteInstance = new FlotteInstance();
        flotteInstance.setId("0");

        SateliteInstance sateliteInstance = new SateliteInstance();
        sateliteInstance.setNom("satelite1");
        sateliteInstance.setParent(flotteInstance);

        flotteInstance.getSatelites().add(sateliteInstance);

        instances = new ArrayList<>();
        instances.add(sateliteInstance);
        instances.add(flotteInstance);

        this.globalRepository.addInstance(flotteInstance);
        this.globalRepository.addInstance(sateliteInstance);

        this.document = globalRepository.ecrire();
    }

    @Test
    void lire() throws IOException, SAXException {
        File file = new File(Constants.PATH_XML_INSTANCE);
        if (!file.exists()) {
            fail();
        }
        Document document= builder.parse(file);
        List<AbstractInstance> instances = this.globalRepository.lire(document);
    }

    @Test
    void ecrire() {
        try {
            Document document = globalRepository.ecrire();

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();

            DOMSource domSource = new DOMSource(document);


            //creating Printstream obj
            File file = new File(Constants.PATH_XML_INSTANCE);
            if (!file.exists()) {
                file.createNewFile();
            }

            PrintStream out = new PrintStream(file);

            StreamResult streamResult = new StreamResult(out);

            transformer.transform(domSource, streamResult);

        } catch (IOException | TransformerException e) {
            e.printStackTrace();
        }
    }
}
